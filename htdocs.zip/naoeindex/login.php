<?php 
include_once('../bd.php');
